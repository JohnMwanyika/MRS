# ecommerce
built with node express for learning sequelize
